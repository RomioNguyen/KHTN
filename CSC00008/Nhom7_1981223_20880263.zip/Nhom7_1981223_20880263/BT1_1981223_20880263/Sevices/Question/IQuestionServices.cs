﻿namespace BT1_1981223_20880263.Sevices
{
    public interface IQuestionServices
    {
        void RunQuestion1(string fileName, bool isUseDataQuestion = true);
        void RunQuestion2(string fileName, bool isUseDataQuestion = true);

    }
}

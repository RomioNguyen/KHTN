﻿namespace BT1_1981223_20880263.Sevices.File
{
    public interface IFileServices
    {
        string GetUrlFile(string fileName);
        string[] GetArrayUrl(string key);
    }
}
